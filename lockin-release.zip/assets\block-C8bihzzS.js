import"./modulepreload-polyfill-B5Qt9EMX.js";import{e as I,g as M,b as D}from"./metadata-DctfkDnG.js";function S(e){return new URLSearchParams(window.location.search).get(e)}function u(e){return e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#039;")}function C(e,t){var n;return((n=e.name)==null?void 0:n.trim())||(t==="video"?`Video ${e.id}`:`Playlist ${e.id}`)}function B(e,t){const n=D(t,e.id);return`
    <tr>
      <td>${u(C(e,t))}</td>
      <td>${t==="video"?"Video":"Playlist"}</td>
      <td class="link-cell">
        <a href="${u(n)}">${u(n)}</a>
      </td>
    </tr>
  `}async function E(){const e=document.getElementById("analogTimer"),t=document.getElementById("hourHand"),n=document.getElementById("minuteHand"),r=document.getElementById("secondHand");if(!e||!t||!n||!r)return;await I();let o=0,s=0,a=0,g=!1;const m=()=>{const l=new Date,f=l.getSeconds()*6,h=l.getMinutes()*6+l.getSeconds()/60*6,y=l.getHours()%12*30+l.getMinutes()/60*30;g||(o=f,s=h,a=y,g=!0);const H=Math.floor(o/360)*360,$=Math.floor(s/360)*360,T=Math.floor(a/360)*360;let i=H+f,c=$+h,d=T+y;i<o-180&&(i+=360),c<s-180&&(c+=360),d<a-180&&(d+=360),o=i,s=c,a=d,r.style.transform=`translateX(-50%) rotate(${o}deg)`,n.style.transform=`translateX(-50%) rotate(${s}deg)`,t.style.transform=`translateX(-50%) rotate(${a}deg)`};m(),setTimeout(()=>{e.classList.add("ticking")},50),setInterval(m,1e3)}async function L(){const e=document.getElementById("whitelistTableBody"),t=document.getElementById("whitelistCount");if(!e||!t)return;const n=await M(),r=[...n.whitelist.videos.map(o=>B(o,"video")),...n.whitelist.playlists.map(o=>B(o,"playlist"))];if(r.length===0){e.innerHTML=`
      <tr class="empty-row">
        <td colspan="3">No whitelisted links yet.</td>
      </tr>
    `,t.textContent="0 links";return}e.innerHTML=r.join(""),t.textContent=`${r.length} ${r.length===1?"link":"links"}`}const p=S("from"),w=p?decodeURIComponent(p):null,k=document.getElementById("urlText");k&&(k.textContent=w?`Blocked: ${w}`:"");E().catch(e=>{console.error("[Lockin Block Page] Could not start timer:",e)});L().catch(e=>{console.error("[Lockin Block Page] Could not render whitelist:",e)});
